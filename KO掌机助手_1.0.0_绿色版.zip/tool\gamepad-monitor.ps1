# 手柄监听脚本 - 持续运行在后台，监听指定手柄按钮
param(
    [string]$Buttons = "-1",  # 要监听的按钮索引，逗号分隔，-1 表示 LB+RB 组合（默认）
    [string]$NircmdPath = ""
)

Add-Type -AssemblyName System.Windows.Forms

# 加载 XInput
Add-Type @"
using System;
using System.Runtime.InteropServices;

public class XInput {
    [DllImport("xinput1_4.dll")]
    public static extern int XInputGetState(int dwUserIndex, ref XINPUT_STATE pState);
    
    [StructLayout(LayoutKind.Sequential)]
    public struct XINPUT_STATE {
        public uint dwPacketNumber;
        public XINPUT_GAMEPAD Gamepad;
    }
    
    [StructLayout(LayoutKind.Sequential)]
    public struct XINPUT_GAMEPAD {
        public ushort wButtons;
        public byte bLeftTrigger;
        public byte bRightTrigger;
        public short sThumbLX;
        public short sThumbLY;
        public short sThumbRX;
        public short sThumbRY;
    }
    
    // 按钮常量
    public const ushort XINPUT_GAMEPAD_DPAD_UP = 0x0001;
    public const ushort XINPUT_GAMEPAD_DPAD_DOWN = 0x0002;
    public const ushort XINPUT_GAMEPAD_DPAD_LEFT = 0x0004;
    public const ushort XINPUT_GAMEPAD_DPAD_RIGHT = 0x0008;
    public const ushort XINPUT_GAMEPAD_START = 0x0010;
    public const ushort XINPUT_GAMEPAD_BACK = 0x0020;
    public const ushort XINPUT_GAMEPAD_LEFT_THUMB = 0x0040;
    public const ushort XINPUT_GAMEPAD_RIGHT_THUMB = 0x0080;
    public const ushort XINPUT_GAMEPAD_LEFT_SHOULDER = 0x0100;
    public const ushort XINPUT_GAMEPAD_RIGHT_SHOULDER = 0x0200;
    public const ushort XINPUT_GAMEPAD_A = 0x1000;
    public const ushort XINPUT_GAMEPAD_B = 0x2000;
    public const ushort XINPUT_GAMEPAD_X = 0x4000;
    public const ushort XINPUT_GAMEPAD_Y = 0x8000;
}
"@

$prevComboPressed = $false
$activeGamepadIndex = -1  # 记录当前活跃的手柄槽位

# 解析按钮列表
$buttonList = $Buttons -split ','
$lastPacketNumbers = @(0, 0, 0, 0)  # 记录每个槽位的 packet number

while ($true) {
    # 先扫描所有槽位，找到有新输入的手柄
    for ($i = 0; $i -lt 4; $i++) {
        $state = New-Object XInput+XINPUT_STATE
        $result = [XInput]::XInputGetState($i, [ref]$state)
        
        if ($result -eq 0) {
            # 检查 packet number 是否变化
            if ($state.dwPacketNumber -ne $lastPacketNumbers[$i]) {
                $lastPacketNumbers[$i] = $state.dwPacketNumber
                
                $buttons = $state.Gamepad.wButtons
                $lt = $state.Gamepad.bLeftTrigger
                $rt = $state.Gamepad.bRightTrigger
                
                # 如果有按钮或扳机被按下，切换到这个手柄
                if ($buttons -ne 0 -or $lt -gt 30 -or $rt -gt 30) {
                    if ($activeGamepadIndex -ne $i) {
                        $activeGamepadIndex = $i
                    }
                    break
                }
            }
        }
    }
    
    # 如果没有活跃槽位，使用第一个连接的手柄
    if ($activeGamepadIndex -lt 0) {
        for ($i = 0; $i -lt 4; $i++) {
            $state = New-Object XInput+XINPUT_STATE
            $result = [XInput]::XInputGetState($i, [ref]$state)
            
            if ($result -eq 0) {
                $activeGamepadIndex = $i
                break
            }
        }
    }
    
    # 如果有活跃手柄，检查按键组合
    if ($activeGamepadIndex -ge 0) {
        $state = New-Object XInput+XINPUT_STATE
        $result = [XInput]::XInputGetState($activeGamepadIndex, [ref]$state)
        
        if ($result -eq 0) {
            $buttons = $state.Gamepad.wButtons
            $lt = $state.Gamepad.bLeftTrigger
            $rt = $state.Gamepad.bRightTrigger
            
            # 检查 LB+RB 组合（默认）
            if ($Buttons -eq "-1") {
                $lb = ($buttons -band [XInput]::XINPUT_GAMEPAD_LEFT_SHOULDER) -ne 0
                $rb = ($buttons -band [XInput]::XINPUT_GAMEPAD_RIGHT_SHOULDER) -ne 0
                $comboPressed = $lb -and $rb
                
                if ($comboPressed -and -not $prevComboPressed) {
                    if ($NircmdPath -ne "") {
                        & $NircmdPath sendkeypress ctrl+shift+g
                    }
                }
                $prevComboPressed = $comboPressed
            }
            # 检查按钮组合
            else {
                $allPressed = $true
                foreach ($btnIdx in $buttonList) {
                    $idx = [int]$btnIdx
                    
                    # 将按钮索引映射到 XInput 按钮位
                    $buttonMask = switch ($idx) {
                        0 { [XInput]::XINPUT_GAMEPAD_A }
                        1 { [XInput]::XINPUT_GAMEPAD_B }
                        2 { [XInput]::XINPUT_GAMEPAD_X }
                        3 { [XInput]::XINPUT_GAMEPAD_Y }
                        4 { [XInput]::XINPUT_GAMEPAD_LEFT_SHOULDER }
                        5 { [XInput]::XINPUT_GAMEPAD_RIGHT_SHOULDER }
                        6 { 0 }  # LT 作为按钮
                        7 { 0 }  # RT 作为按钮
                        8 { [XInput]::XINPUT_GAMEPAD_BACK }
                        9 { [XInput]::XINPUT_GAMEPAD_START }
                        10 { [XInput]::XINPUT_GAMEPAD_LEFT_THUMB }
                        11 { [XInput]::XINPUT_GAMEPAD_RIGHT_THUMB }
                        default { 0 }
                    }
                    
                    $buttonPressed = $false
                    if ($idx -eq 6) {
                        $buttonPressed = $lt -gt 30
                    } elseif ($idx -eq 7) {
                        $buttonPressed = $rt -gt 30
                    } elseif ($buttonMask -ne 0) {
                        $buttonPressed = ($buttons -band $buttonMask) -ne 0
                    }
                    
                    if (-not $buttonPressed) {
                        $allPressed = $false
                        break
                    }
                }
                
                if ($allPressed -and -not $prevComboPressed) {
                    if ($NircmdPath -ne "") {
                        & $NircmdPath sendkeypress ctrl+shift+g
                    }
                }
                $prevComboPressed = $allPressed
            }
        }
    }
    
    Start-Sleep -Milliseconds 50
}
