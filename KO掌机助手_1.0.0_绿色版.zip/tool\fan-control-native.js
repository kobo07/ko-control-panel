// 完整风扇控制模块
// 支持所有 MotionAssistant 中的设备
// 包括: EC RAM, EC I/O, ACPI, WMI 等多种控制方式

const ffi = require('ffi-napi');
const ref = require('ref-napi');
const path = require('path');
const { execSync } = require('child_process');

// 加载 WinRing0x64.dll (从 ryzenadj 目录)
const winRing0Path = path.join(__dirname, 'ryzenadj-win64', 'WinRing0x64.dll');

let winRing0;
try {
  winRing0 = ffi.Library(winRing0Path, {
    'InitializeOls': ['bool', []],
    'DeinitializeOls': ['void', []],
    'GetDllStatus': ['uint', []],
    'ReadIoPortByte': ['byte', ['ushort']],
    'WriteIoPortByte': ['void', ['ushort', 'byte']],
    'ReadIoPortWord': ['ushort', ['ushort']],
    'WriteIoPortWord': ['void', ['ushort', 'ushort']]
  });
} catch (error) {
  console.error('Failed to load WinRing0x64.dll:', error.message);
  winRing0 = null;
}

// Super I/O 端口地址
const SUPER_IO_4E4F = { ADDR: 0x4E, DATA: 0x4F };  // 标准端口
const SUPER_IO_2E2F = { ADDR: 0x2E, DATA: 0x2F };  // 备用端口 (Win 4 6800U)

// 当前设备配置
let currentDeviceConfig = null;
let currentPortType = SUPER_IO_4E4F;

// 风扇曲线定义
const FAN_CURVES = {
  0: [ // 静音模式
    { temp: 40, speed: 20 },
    { temp: 50, speed: 30 },
    { temp: 60, speed: 40 },
    { temp: 70, speed: 55 },
    { temp: 80, speed: 70 },
    { temp: 90, speed: 85 }
  ],
  1: [ // 平衡模式
    { temp: 40, speed: 30 },
    { temp: 50, speed: 40 },
    { temp: 60, speed: 50 },
    { temp: 70, speed: 65 },
    { temp: 80, speed: 80 },
    { temp: 90, speed: 95 }
  ],
  2: [ // 性能模式
    { temp: 40, speed: 60 },
    { temp: 50, speed: 70 },
    { temp: 60, speed: 80 },
    { temp: 70, speed: 85 },
    { temp: 80, speed: 90 },
    { temp: 90, speed: 100 }
  ],
  3: [ // 狂暴模式
    { temp: 40, speed: 50 },
    { temp: 50, speed: 65 },
    { temp: 60, speed: 80 },
    { temp: 70, speed: 90 },
    { temp: 80, speed: 95 },
    { temp: 90, speed: 100 }
  ]
};

/**
 * 设置设备配置
 * @param {Object} deviceConfig - 从 device-detection.js 获取的设备配置
 */
function setDeviceConfig(deviceConfig) {
  if (!deviceConfig || !deviceConfig.fanControl) {
    throw new Error('Invalid device config or fan control not supported');
  }
  
  currentDeviceConfig = deviceConfig.fanControl;
  
  // 设置端口类型
  if (currentDeviceConfig.portType === '2E2F') {
    currentPortType = SUPER_IO_2E2F;
    console.log('Using 2E2F port for EC access');
  } else {
    currentPortType = SUPER_IO_4E4F;
    console.log('Using 4E4F port for EC access');
  }
  
  console.log(`Device config set for: ${deviceConfig.name}`);
  console.log('Fan control addresses:', currentDeviceConfig.addresses);
  console.log('Max fan speed:', currentDeviceConfig.maxSpeed);
  
  return true;
}

/**
 * 初始化 WinRing0 驱动
 */
function initialize() {
  if (!winRing0) {
    throw new Error('WinRing0 library not loaded');
  }
  
  const result = winRing0.InitializeOls();
  if (!result) {
    const status = winRing0.GetDllStatus();
    throw new Error(`Failed to initialize WinRing0, status: ${status}`);
  }
  
  return true;
}

/**
 * 清理 WinRing0 驱动
 */
function cleanup() {
  if (winRing0) {
    winRing0.DeinitializeOls();
  }
}

/**
 * 写入 EC RAM (通过 Super I/O)
 * 支持 4E4F 和 2E2F 两种端口
 */
function writeECRam(address, data) {
  if (!winRing0) {
    throw new Error('WinRing0 not initialized');
  }
  
  const highByte = (address >> 8) & 0xFF;
  const lowByte = address & 0xFF;
  const port = currentPortType;
  
  // 写入高字节地址
  winRing0.WriteIoPortByte(port.ADDR, 0x2E);
  winRing0.WriteIoPortByte(port.DATA, 0x11);
  winRing0.WriteIoPortByte(port.ADDR, 0x2F);
  winRing0.WriteIoPortByte(port.DATA, highByte);
  
  // 写入低字节地址
  winRing0.WriteIoPortByte(port.ADDR, 0x2E);
  winRing0.WriteIoPortByte(port.DATA, 0x10);
  winRing0.WriteIoPortByte(port.ADDR, 0x2F);
  winRing0.WriteIoPortByte(port.DATA, lowByte);
  
  // 写入数据
  winRing0.WriteIoPortByte(port.ADDR, 0x2E);
  winRing0.WriteIoPortByte(port.DATA, 0x12);
  winRing0.WriteIoPortByte(port.ADDR, 0x2F);
  winRing0.WriteIoPortByte(port.DATA, data);
}

/**
 * 读取 EC RAM (通过 Super I/O)
 */
function readECRam(address) {
  if (!winRing0) {
    throw new Error('WinRing0 not initialized');
  }
  
  const highByte = (address >> 8) & 0xFF;
  const lowByte = address & 0xFF;
  const port = currentPortType;
  
  // 写入高字节地址
  winRing0.WriteIoPortByte(port.ADDR, 0x2E);
  winRing0.WriteIoPortByte(port.DATA, 0x11);
  winRing0.WriteIoPortByte(port.ADDR, 0x2F);
  winRing0.WriteIoPortByte(port.DATA, highByte);
  
  // 写入低字节地址
  winRing0.WriteIoPortByte(port.ADDR, 0x2E);
  winRing0.WriteIoPortByte(port.DATA, 0x10);
  winRing0.WriteIoPortByte(port.ADDR, 0x2F);
  winRing0.WriteIoPortByte(port.DATA, lowByte);
  
  // 读取数据
  winRing0.WriteIoPortByte(port.ADDR, 0x2E);
  winRing0.WriteIoPortByte(port.DATA, 0x12);
  winRing0.WriteIoPortByte(port.ADDR, 0x2F);
  return winRing0.ReadIoPortByte(port.DATA);
}

/**
 * 写入 EC I/O 端口 (用于 Zotac, Orange Pi 等设备)
 */
function writeECIO(port, data) {
  if (!winRing0) {
    throw new Error('WinRing0 not initialized');
  }
  winRing0.WriteIoPortByte(port, data);
}

/**
 * 读取 EC I/O 端口
 */
function readECIO(port) {
  if (!winRing0) {
    throw new Error('WinRing0 not initialized');
  }
  return winRing0.ReadIoPortByte(port);
}

/**
 * ROG Ally 风扇控制 (使用 WMI ACPI 接口)
 */
function setFanSpeedROGAlly(speedPercent) {
  try {
    // ROG Ally 使用 ASUS WMI ACPI 接口
    // DeviceID: 0x00110013 (CPU Fan), 0x00110014 (GPU Fan)
    const speedValue = Math.round(speedPercent);
    
    // 使用 PowerShell 调用 WMI
    const script = `
      $namespace = "root\\WMI"
      $className = "AsusAtkWmi_WMNB"
      $deviceId = 0x00110013
      $methodId = 0x53564544
      
      $wmi = Get-WmiObject -Namespace $namespace -Class $className
      if ($wmi) {
        $wmi.DEVS($methodId, $deviceId, ${speedValue})
      }
    `;
    
    execSync(`powershell -Command "${script.replace(/\n/g, ' ')}"`, { encoding: 'utf8' });
    console.log(`ROG Ally fan speed set to ${speedPercent}%`);
    return true;
  } catch (error) {
    console.error('Failed to set ROG Ally fan speed:', error.message);
    return false;
  }
}

/**
 * Legion Go 风扇控制 (使用 Lenovo WMI 接口)
 */
function setFanSpeedLegionGo(speedPercent) {
  try {
    initialize();
    
    const speedValue = Math.round((speedPercent / 100) * 245);
    
    // Legion Go 使用 EC RAM 地址 0x1802 (6146)
    for (let i = 0; i < 4; i++) {
      writeECRam(0x1802, speedValue);
      // 需要延迟确保写入成功
      const start = Date.now();
      while (Date.now() - start < 250) {
        // 延迟 250ms
      }
    }
    
    console.log(`Legion Go fan speed set to ${speedPercent}%`);
    return true;
  } catch (error) {
    console.error('Failed to set Legion Go fan speed:', error.message);
    return false;
  } finally {
    cleanup();
  }
}

/**
 * Zotac Zone 风扇控制 (使用 EC I/O 端口)
 */
function setFanSpeedZotac(speedPercent) {
  try {
    initialize();
    
    const speedValue = Math.round((speedPercent / 100) * 255);
    
    // Zotac 使用 EC I/O 端口 0x4A (模式), 0x4B (速度)
    writeECIO(0x4A, 1); // 设置为手动模式
    writeECIO(0x4B, speedValue); // 设置速度
    
    console.log(`Zotac fan speed set to ${speedPercent}%`);
    return true;
  } catch (error) {
    console.error('Failed to set Zotac fan speed:', error.message);
    return false;
  } finally {
    cleanup();
  }
}

/**
 * Orange Pi Neo 风扇控制 (使用 EC I/O 端口)
 */
function setFanSpeedOrangePi(speedPercent) {
  try {
    initialize();
    
    const speedValue = Math.round((speedPercent / 100) * 244);
    
    // Orange Pi 使用 EC I/O 端口 0x40 (模式), 0x38 (速度)
    writeECIO(0x40, 1); // 设置为手动模式
    writeECIO(0x38, speedValue); // 设置速度
    
    console.log(`Orange Pi fan speed set to ${speedPercent}%`);
    return true;
  } catch (error) {
    console.error('Failed to set Orange Pi fan speed:', error.message);
    return false;
  } finally {
    cleanup();
  }
}

/**
 * 设置风扇转速 (手动模式) - 统一接口
 * @param {number} speedPercent - 转速百分比 (0-100)
 */
function setFanSpeed(speedPercent) {
  if (!currentDeviceConfig) {
    throw new Error('Device config not set. Call setDeviceConfig() first');
  }
  
  if (speedPercent < 0 || speedPercent > 100) {
    throw new Error('Speed must be between 0 and 100');
  }
  
  // 根据设备类型选择控制方式
  const controlType = currentDeviceConfig.type;
  
  if (controlType === 'ACPI') {
    return setFanSpeedROGAlly(speedPercent);
  } else if (controlType === 'WMI') {
    return setFanSpeedLegionGo(speedPercent);
  } else if (controlType === 'ECIO') {
    if (currentDeviceConfig.addresses.mode === 0x4A) {
      return setFanSpeedZotac(speedPercent);
    } else {
      return setFanSpeedOrangePi(speedPercent);
    }
  }
  
  // 标准 EC RAM 控制
  try {
    initialize();
    
    const addresses = currentDeviceConfig.addresses;
    const maxSpeed = currentDeviceConfig.maxSpeed;
    const speedValue = Math.round((speedPercent / 100) * maxSpeed);
    
    console.log(`Setting fan speed to ${speedPercent}% (${speedValue}/${maxSpeed})`);
    
    // 如果有 mode 寄存器，先设置为手动模式
    if (addresses.mode !== undefined) {
      writeECRam(addresses.mode, 1);
    }
    
    // 写入主控制寄存器
    if (addresses.control !== undefined) {
      writeECRam(addresses.control, speedValue);
    }
    
    // 写入第二个控制寄存器 (某些设备有双风扇)
    if (addresses.control2 !== undefined) {
      writeECRam(addresses.control2, speedValue);
    }
    
    // 写入第三、第四个控制寄存器 (Win 3)
    if (addresses.control3 !== undefined) {
      writeECRam(addresses.control3, 1);
    }
    if (addresses.control4 !== undefined) {
      writeECRam(addresses.control4, speedValue);
    }
    
    console.log('Fan speed set successfully');
    return true;
  } catch (error) {
    console.error('Failed to set fan speed:', error.message);
    throw error;
  } finally {
    cleanup();
  }
}

/**
 * 设置风扇曲线 (通过设置固定转速实现)
 * @param {number} modeIndex - 风扇模式索引 (0-3)
 */
function setFanCurve(modeIndex) {
  if (!FAN_CURVES[modeIndex]) {
    throw new Error(`Invalid fan mode index: ${modeIndex}`);
  }
  
  const curve = FAN_CURVES[modeIndex];
  console.log(`Setting fan curve for mode ${modeIndex}:`, curve);
  
  // 使用曲线中 60°C 的转速作为基准
  const basePoint = curve.find(p => p.temp === 60) || curve[2];
  
  try {
    return setFanSpeed(basePoint.speed);
  } catch (error) {
    console.error('Failed to set fan curve:', error.message);
    throw error;
  }
}

/**
 * 恢复自动风扇控制 - 统一接口
 */
function setFanAuto() {
  if (!currentDeviceConfig) {
    throw new Error('Device config not set. Call setDeviceConfig() first');
  }
  
  const controlType = currentDeviceConfig.type;
  
  // ROG Ally 自动模式
  if (controlType === 'ACPI') {
    try {
      const script = `
        $namespace = "root\\WMI"
        $className = "AsusAtkWmi_WMNB"
        $deviceId = 0x00120075
        $methodId = 0x53564544
        
        $wmi = Get-WmiObject -Namespace $namespace -Class $className
        if ($wmi) {
          $wmi.DEVS($methodId, $deviceId, 1)
        }
      `;
      execSync(`powershell -Command "${script.replace(/\n/g, ' ')}"`, { encoding: 'utf8' });
      console.log('ROG Ally fan control set to auto');
      return true;
    } catch (error) {
      console.error('Failed to set ROG Ally to auto:', error.message);
      return false;
    }
  }
  
  // Zotac 自动模式
  if (controlType === 'ECIO' && currentDeviceConfig.addresses.mode === 0x4A) {
    try {
      initialize();
      writeECIO(0x4A, 0);
      writeECIO(0x4B, 0);
      console.log('Zotac fan control set to auto');
      return true;
    } catch (error) {
      console.error('Failed to set Zotac to auto:', error.message);
      return false;
    } finally {
      cleanup();
    }
  }
  
  // Orange Pi 自动模式
  if (controlType === 'ECIO' && currentDeviceConfig.addresses.mode === 0x40) {
    try {
      initialize();
      writeECIO(0x40, 0);
      writeECIO(0x38, 0);
      console.log('Orange Pi fan control set to auto');
      return true;
    } catch (error) {
      console.error('Failed to set Orange Pi to auto:', error.message);
      return false;
    } finally {
      cleanup();
    }
  }
  
  // 标准 EC RAM 自动模式
  try {
    initialize();
    
    const addresses = currentDeviceConfig.addresses;
    
    // 如果有 mode 寄存器，设置为自动模式
    if (addresses.mode !== undefined) {
      writeECRam(addresses.mode, 0);
    }
    
    // 清零控制寄存器
    if (addresses.control !== undefined) {
      writeECRam(addresses.control, 0);
    }
    
    if (addresses.control2 !== undefined) {
      writeECRam(addresses.control2, 0);
    }
    
    if (addresses.control3 !== undefined) {
      writeECRam(addresses.control3, 0);
    }
    
    if (addresses.control4 !== undefined) {
      writeECRam(addresses.control4, 0);
    }
    
    console.log('Fan control set to auto');
    return true;
  } catch (error) {
    console.error('Failed to set fan to auto:', error.message);
    throw error;
  } finally {
    cleanup();
  }
}

/**
 * 读取当前风扇转速
 */
function getFanSpeed() {
  if (!currentDeviceConfig) {
    throw new Error('Device config not set. Call setDeviceConfig() first');
  }
  
  try {
    initialize();
    
    const speedRead = currentDeviceConfig.speedRead;
    const maxSpeed = currentDeviceConfig.maxSpeed;
    
    let speedValue;
    
    // 读取转速 (某些设备是 16 位值)
    if (speedRead.high !== undefined && speedRead.low !== undefined) {
      const low = readECRam(speedRead.low);
      const high = readECRam(speedRead.high);
      speedValue = (high << 8) | low;
    } else if (speedRead.value !== undefined) {
      speedValue = readECRam(speedRead.value);
    } else {
      throw new Error('Invalid speed read configuration');
    }
    
    const speedPercent = Math.round((speedValue / maxSpeed) * 100);
    
    console.log(`Current fan speed: ${speedPercent}% (${speedValue}/${maxSpeed})`);
    return speedPercent;
  } catch (error) {
    console.error('Failed to read fan speed:', error.message);
    return -1;
  } finally {
    cleanup();
  }
}

module.exports = {
  initialize,
  cleanup,
  setDeviceConfig,
  setFanCurve,
  setFanSpeed,
  setFanAuto,
  getFanSpeed,
  writeECRam,
  readECRam,
  FAN_CURVES
};
