# 获取当前播放的媒体信息 (Windows Media Session)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Add-Type -AssemblyName System.Runtime.WindowsRuntime

# 辅助函数：等待 WinRT IAsyncOperation 使用反射调用 AsTask
function Await-WinRT($asyncOp, $resultType) {
    $asTaskMethod = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { 
        $_.Name -eq 'AsTask' -and 
        $_.GetParameters().Count -eq 1 -and 
        $_.IsGenericMethod 
    } | Select-Object -First 1
    
    $genericMethod = $asTaskMethod.MakeGenericMethod($resultType)
    $task = $genericMethod.Invoke($null, @($asyncOp))
    $null = $task.Wait()
    return $task.Result
}

try {
    # 加载 WinRT 类型
    $null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
    
    # 请求 Session Manager
    $asyncOp = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()
    $sessionManager = Await-WinRT $asyncOp ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
    
    # 获取当前会话
    $session = $sessionManager.GetCurrentSession()
    
    if ($null -ne $session) {
        # 获取媒体属性
        $propsOp = $session.TryGetMediaPropertiesAsync()
        $mediaProps = Await-WinRT $propsOp ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
        
        # 获取播放状态
        $playbackInfo = $session.GetPlaybackInfo()
        $status = $playbackInfo.PlaybackStatus.ToString()
        
        $title = if ($mediaProps.Title) { $mediaProps.Title } else { "" }
        $artist = if ($mediaProps.Artist) { $mediaProps.Artist } else { "" }
        $album = if ($mediaProps.AlbumTitle) { $mediaProps.AlbumTitle } else { "" }
        
        # 转义 JSON 特殊字符
        $title = $title -replace '\\', '\\\\' -replace '"', '\"' -replace "`n", '\n' -replace "`r", '\r'
        $artist = $artist -replace '\\', '\\\\' -replace '"', '\"' -replace "`n", '\n' -replace "`r", '\r'
        $album = $album -replace '\\', '\\\\' -replace '"', '\"' -replace "`n", '\n' -replace "`r", '\r'
        
        Write-Output "{`"hasMedia`":true,`"title`":`"$title`",`"artist`":`"$artist`",`"album`":`"$album`",`"status`":`"$status`"}"
    } else {
        Write-Output '{"hasMedia":false}'
    }
} catch {
    $errMsg = $_.Exception.Message -replace '"', '\"'
    Write-Output "{`"hasMedia`":false,`"error`":`"$errMsg`"}"
}
