//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by qresext.RC
//
#define IDC_STDTXT                      102
#define IDD_QRESPAGE                    132
#define IDC_QRES_OFF                    1002
#define IDC_QRES_ON                     1003
#define IDC_EDIT1                       1004
#define IDC_COLORBOX                    1005
#define IDC_AREABOX                     1006
#define IDC_COLOR                       1010
#define IDC_AREA                        1011
#define IDC_AREA_TXT                    1012
#define IDC_RESTORE                     1013
#define IDC_NOCOLOR                     1027
#define IDC_NOAREA                      1028
#define IDC_LESS                        1029
#define IDC_MORE                        1030
#define IDC_STDICON                     13057

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
