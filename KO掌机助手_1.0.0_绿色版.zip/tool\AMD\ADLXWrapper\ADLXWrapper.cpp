//
// ADLX Wrapper DLL - 简化的 C 接口供 Rust 调用
// Copyright (c) 2024
//

#include "../ADLX/SDK/ADLXHelper/Windows/Cpp/ADLXHelper.h"
#include "../ADLX/SDK/Include/I3DSettings.h"
#include "../ADLX/SDK/Include/IDisplays.h"
#include "../ADLX/SDK/Include/IDisplaySettings.h"
#include "../ADLX/SDK/Include/IPerformanceMonitoring.h"
#include <mutex>

using namespace adlx;

// 全局 ADLX Helper 实例
static ADLXHelper g_ADLXHelp;
static std::mutex g_mutex;
static bool g_initialized = false;

// 导出宏
#ifdef _WIN32
#define EXPORT extern "C" __declspec(dllexport)
#else
#define EXPORT extern "C"
#endif

// ==================== 初始化和销毁 ====================

EXPORT int ADLX_Initialize()
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_initialized)
        return 0; // 已初始化
    
    ADLX_RESULT res = g_ADLXHelp.Initialize();
    if (ADLX_SUCCEEDED(res))
    {
        g_initialized = true;
        return 0;
    }
    return (int)res;
}

EXPORT int ADLX_Terminate()
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_initialized)
        return 0;
    
    ADLX_RESULT res = g_ADLXHelp.Terminate();
    g_initialized = false;
    return (int)res;
}

EXPORT bool ADLX_IsInitialized()
{
    return g_initialized;
}

// 内部自动初始化函数（无锁版本，调用者需持有锁）
static bool ensureInitialized()
{
    if (g_initialized) return true;
    ADLX_RESULT res = g_ADLXHelp.Initialize();
    if (ADLX_SUCCEEDED(res)) {
        g_initialized = true;
        return true;
    }
    return false;
}

// ==================== RSR (Radeon Super Resolution) ====================

// 诊断函数：返回详细错误码
// 返回值: 0=支持, 1=不支持, 2=已启用(视为支持), -1=初始化失败, -2=获取3D设置服务失败, -3=获取RSR接口失败
EXPORT int ADLX_RSR_GetSupportStatus()
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return -2;
    
    IADLX3DRadeonSuperResolutionPtr rsr;
    res = d3dSettingSrv->GetRadeonSuperResolution(&rsr);
    if (!ADLX_SUCCEEDED(res)) return -3;
    
    // 先检查是否已启用（如果已启用，说明肯定支持）
    adlx_bool enabled = false;
    rsr->IsEnabled(&enabled);
    if (enabled) return 2; // 已启用，视为支持
    
    adlx_bool supported = false;
    rsr->IsSupported(&supported);
    return supported ? 0 : 1;
}

EXPORT bool ADLX_RSR_IsSupported()
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLX3DRadeonSuperResolutionPtr rsr;
    res = d3dSettingSrv->GetRadeonSuperResolution(&rsr);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool supported = false;
    rsr->IsSupported(&supported);
    return supported;
}

EXPORT bool ADLX_RSR_IsEnabled()
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLX3DRadeonSuperResolutionPtr rsr;
    res = d3dSettingSrv->GetRadeonSuperResolution(&rsr);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool enabled = false;
    rsr->IsEnabled(&enabled);
    return enabled;
}

EXPORT int ADLX_RSR_SetEnabled(bool enabled)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLX3DRadeonSuperResolutionPtr rsr;
    res = d3dSettingSrv->GetRadeonSuperResolution(&rsr);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = rsr->SetEnabled(enabled);
    return (int)res;
}

EXPORT int ADLX_RSR_GetSharpness()
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return 50;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return 50;
    
    IADLX3DRadeonSuperResolutionPtr rsr;
    res = d3dSettingSrv->GetRadeonSuperResolution(&rsr);
    if (!ADLX_SUCCEEDED(res)) return 50;
    
    adlx_int sharpness = 50;
    rsr->GetSharpness(&sharpness);
    return sharpness;
}

EXPORT int ADLX_RSR_SetSharpness(int sharpness)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLX3DRadeonSuperResolutionPtr rsr;
    res = d3dSettingSrv->GetRadeonSuperResolution(&rsr);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = rsr->SetSharpness(sharpness);
    return (int)res;
}

// ==================== FreeSync ====================

EXPORT bool ADLX_FreeSync_IsSupported(int displayIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLXDisplayServicesPtr displayService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetDisplaysServices(&displayService);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayListPtr displayList;
    res = displayService->GetDisplays(&displayList);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_uint count = displayList->Size();
    if (displayIndex >= (int)count) return false;
    
    IADLXDisplayPtr display;
    res = displayList->At(displayIndex, &display);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayFreeSyncPtr freeSync;
    res = displayService->GetFreeSync(display, &freeSync);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool supported = false;
    freeSync->IsSupported(&supported);
    return supported;
}

EXPORT bool ADLX_FreeSync_IsEnabled(int displayIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLXDisplayServicesPtr displayService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetDisplaysServices(&displayService);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayListPtr displayList;
    res = displayService->GetDisplays(&displayList);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_uint count = displayList->Size();
    if (displayIndex >= (int)count) return false;
    
    IADLXDisplayPtr display;
    res = displayList->At(displayIndex, &display);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayFreeSyncPtr freeSync;
    res = displayService->GetFreeSync(display, &freeSync);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool enabled = false;
    freeSync->IsEnabled(&enabled);
    return enabled;
}

EXPORT int ADLX_FreeSync_SetEnabled(int displayIndex, bool enabled)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLXDisplayServicesPtr displayService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetDisplaysServices(&displayService);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXDisplayListPtr displayList;
    res = displayService->GetDisplays(&displayList);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = displayList->Size();
    if (displayIndex >= (int)count) return -1;
    
    IADLXDisplayPtr display;
    res = displayList->At(displayIndex, &display);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXDisplayFreeSyncPtr freeSync;
    res = displayService->GetFreeSync(display, &freeSync);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = freeSync->SetEnabled(enabled);
    return (int)res;
}

// ==================== GPU Scaling ====================

EXPORT bool ADLX_GPUScaling_IsSupported(int displayIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLXDisplayServicesPtr displayService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetDisplaysServices(&displayService);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayListPtr displayList;
    res = displayService->GetDisplays(&displayList);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_uint count = displayList->Size();
    if (displayIndex >= (int)count) return false;
    
    IADLXDisplayPtr display;
    res = displayList->At(displayIndex, &display);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayGPUScalingPtr gpuScaling;
    res = displayService->GetGPUScaling(display, &gpuScaling);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool supported = false;
    gpuScaling->IsSupported(&supported);
    return supported;
}

EXPORT bool ADLX_GPUScaling_IsEnabled(int displayIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLXDisplayServicesPtr displayService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetDisplaysServices(&displayService);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayListPtr displayList;
    res = displayService->GetDisplays(&displayList);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_uint count = displayList->Size();
    if (displayIndex >= (int)count) return false;
    
    IADLXDisplayPtr display;
    res = displayList->At(displayIndex, &display);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayGPUScalingPtr gpuScaling;
    res = displayService->GetGPUScaling(display, &gpuScaling);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool enabled = false;
    gpuScaling->IsEnabled(&enabled);
    return enabled;
}

EXPORT int ADLX_GPUScaling_SetEnabled(int displayIndex, bool enabled)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLXDisplayServicesPtr displayService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetDisplaysServices(&displayService);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXDisplayListPtr displayList;
    res = displayService->GetDisplays(&displayList);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = displayList->Size();
    if (displayIndex >= (int)count) return -1;
    
    IADLXDisplayPtr display;
    res = displayList->At(displayIndex, &display);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXDisplayGPUScalingPtr gpuScaling;
    res = displayService->GetGPUScaling(display, &gpuScaling);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = gpuScaling->SetEnabled(enabled);
    return (int)res;
}

// ==================== Integer Scaling (整数缩放) ====================

EXPORT bool ADLX_IntegerScaling_IsSupported(int displayIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLXDisplayServicesPtr displayService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetDisplaysServices(&displayService);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayListPtr displayList;
    res = displayService->GetDisplays(&displayList);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_uint count = displayList->Size();
    if (displayIndex >= (int)count) return false;
    
    IADLXDisplayPtr display;
    res = displayList->At(displayIndex, &display);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayIntegerScalingPtr integerScaling;
    res = displayService->GetIntegerScaling(display, &integerScaling);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool supported = false;
    integerScaling->IsSupported(&supported);
    return supported;
}

EXPORT bool ADLX_IntegerScaling_IsEnabled(int displayIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLXDisplayServicesPtr displayService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetDisplaysServices(&displayService);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayListPtr displayList;
    res = displayService->GetDisplays(&displayList);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_uint count = displayList->Size();
    if (displayIndex >= (int)count) return false;
    
    IADLXDisplayPtr display;
    res = displayList->At(displayIndex, &display);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayIntegerScalingPtr integerScaling;
    res = displayService->GetIntegerScaling(display, &integerScaling);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool enabled = false;
    integerScaling->IsEnabled(&enabled);
    return enabled;
}

EXPORT int ADLX_IntegerScaling_SetEnabled(int displayIndex, bool enabled)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLXDisplayServicesPtr displayService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetDisplaysServices(&displayService);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXDisplayListPtr displayList;
    res = displayService->GetDisplays(&displayList);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = displayList->Size();
    if (displayIndex >= (int)count) return -1;
    
    IADLXDisplayPtr display;
    res = displayList->At(displayIndex, &display);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXDisplayIntegerScalingPtr integerScaling;
    res = displayService->GetIntegerScaling(display, &integerScaling);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = integerScaling->SetEnabled(enabled);
    return (int)res;
}

// ==================== Scaling Mode (缩放模式) ====================
// Mode: 0 = PRESERVE_ASPECT_RATIO (保持比例)
//       1 = FULL_PANEL (全屏拉伸)
//       2 = CENTERED (居中显示)

EXPORT bool ADLX_ScalingMode_IsSupported(int displayIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLXDisplayServicesPtr displayService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetDisplaysServices(&displayService);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayListPtr displayList;
    res = displayService->GetDisplays(&displayList);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_uint count = displayList->Size();
    if (displayIndex >= (int)count) return false;
    
    IADLXDisplayPtr display;
    res = displayList->At(displayIndex, &display);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXDisplayScalingModePtr scalingMode;
    res = displayService->GetScalingMode(display, &scalingMode);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool supported = false;
    scalingMode->IsSupported(&supported);
    return supported;
}

EXPORT int ADLX_ScalingMode_GetMode(int displayIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return 0;
    
    IADLXDisplayServicesPtr displayService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetDisplaysServices(&displayService);
    if (!ADLX_SUCCEEDED(res)) return 0;
    
    IADLXDisplayListPtr displayList;
    res = displayService->GetDisplays(&displayList);
    if (!ADLX_SUCCEEDED(res)) return 0;
    
    adlx_uint count = displayList->Size();
    if (displayIndex >= (int)count) return 0;
    
    IADLXDisplayPtr display;
    res = displayList->At(displayIndex, &display);
    if (!ADLX_SUCCEEDED(res)) return 0;
    
    IADLXDisplayScalingModePtr scalingMode;
    res = displayService->GetScalingMode(display, &scalingMode);
    if (!ADLX_SUCCEEDED(res)) return 0;
    
    ADLX_SCALE_MODE mode = PRESERVE_ASPECT_RATIO;
    scalingMode->GetMode(&mode);
    return (int)mode;
}

EXPORT int ADLX_ScalingMode_SetMode(int displayIndex, int mode)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLXDisplayServicesPtr displayService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetDisplaysServices(&displayService);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXDisplayListPtr displayList;
    res = displayService->GetDisplays(&displayList);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = displayList->Size();
    if (displayIndex >= (int)count) return -1;
    
    IADLXDisplayPtr display;
    res = displayList->At(displayIndex, &display);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXDisplayScalingModePtr scalingMode;
    res = displayService->GetScalingMode(display, &scalingMode);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = scalingMode->SetMode((ADLX_SCALE_MODE)mode);
    return (int)res;
}

// ==================== Frame Rate Target Control (FPS 限制) ====================

EXPORT bool ADLX_FRTC_IsSupported(int gpuIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return false;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLX3DFrameRateTargetControlPtr frtc;
    res = d3dSettingSrv->GetFrameRateTargetControl(gpu, &frtc);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool supported = false;
    frtc->IsSupported(&supported);
    return supported;
}

EXPORT bool ADLX_FRTC_IsEnabled(int gpuIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return false;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLX3DFrameRateTargetControlPtr frtc;
    res = d3dSettingSrv->GetFrameRateTargetControl(gpu, &frtc);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool enabled = false;
    frtc->IsEnabled(&enabled);
    return enabled;
}

EXPORT int ADLX_FRTC_GetFPS(int gpuIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return 60;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return 60;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return 60;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return 60;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return 60;
    
    IADLX3DFrameRateTargetControlPtr frtc;
    res = d3dSettingSrv->GetFrameRateTargetControl(gpu, &frtc);
    if (!ADLX_SUCCEEDED(res)) return 60;
    
    adlx_int fps = 60;
    frtc->GetFPS(&fps);
    return fps;
}

EXPORT int ADLX_FRTC_SetEnabled(int gpuIndex, bool enabled)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return -1;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLX3DFrameRateTargetControlPtr frtc;
    res = d3dSettingSrv->GetFrameRateTargetControl(gpu, &frtc);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = frtc->SetEnabled(enabled);
    return (int)res;
}

EXPORT int ADLX_FRTC_SetFPS(int gpuIndex, int fps)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return -1;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLX3DFrameRateTargetControlPtr frtc;
    res = d3dSettingSrv->GetFrameRateTargetControl(gpu, &frtc);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = frtc->SetFPS(fps);
    return (int)res;
}

// ==================== GPU Metrics ====================

struct GPUMetricsData
{
    int gpuUsage;
    int gpuClock;
    int vramClock;
    int gpuTemp;
    int hotspotTemp;
    int gpuPower;
    int fanSpeed;
    int vramUsage;
    int gpuVoltage;
};

EXPORT int ADLX_GetGPUMetrics(int gpuIndex, GPUMetricsData* data)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized() || !data) return -1;
    
    // 初始化为 0
    memset(data, 0, sizeof(GPUMetricsData));
    
    IADLXPerformanceMonitoringServicesPtr perfMonitoringService;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->GetPerformanceMonitoringServices(&perfMonitoringService);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return -1;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXGPUMetricsSupportPtr metricsSupport;
    res = perfMonitoringService->GetSupportedGPUMetrics(gpu, &metricsSupport);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXGPUMetricsPtr metrics;
    res = perfMonitoringService->GetCurrentGPUMetrics(gpu, &metrics);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    // 获取各项指标
    adlx_double dValue;
    adlx_int iValue;
    
    if (ADLX_SUCCEEDED(metrics->GPUUsage(&dValue)))
        data->gpuUsage = (int)dValue;
    
    if (ADLX_SUCCEEDED(metrics->GPUClockSpeed(&iValue)))
        data->gpuClock = iValue;
    
    if (ADLX_SUCCEEDED(metrics->GPUVRAMClockSpeed(&iValue)))
        data->vramClock = iValue;
    
    if (ADLX_SUCCEEDED(metrics->GPUTemperature(&dValue)))
        data->gpuTemp = (int)dValue;
    
    if (ADLX_SUCCEEDED(metrics->GPUHotspotTemperature(&dValue)))
        data->hotspotTemp = (int)dValue;
    
    if (ADLX_SUCCEEDED(metrics->GPUPower(&dValue)))
        data->gpuPower = (int)dValue;
    
    if (ADLX_SUCCEEDED(metrics->GPUFanSpeed(&iValue)))
        data->fanSpeed = iValue;
    
    if (ADLX_SUCCEEDED(metrics->GPUVRAM(&iValue)))
        data->vramUsage = iValue;
    
    if (ADLX_SUCCEEDED(metrics->GPUVoltage(&iValue)))
        data->gpuVoltage = iValue;
    
    return 0;
}

// ==================== Anti-Lag ====================

EXPORT bool ADLX_AntiLag_IsEnabled(int gpuIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return false;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLX3DAntiLagPtr antiLag;
    res = d3dSettingSrv->GetAntiLag(gpu, &antiLag);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool enabled = false;
    antiLag->IsEnabled(&enabled);
    return enabled;
}

EXPORT int ADLX_AntiLag_SetEnabled(int gpuIndex, bool enabled)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return -1;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLX3DAntiLagPtr antiLag;
    res = d3dSettingSrv->GetAntiLag(gpu, &antiLag);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = antiLag->SetEnabled(enabled);
    return (int)res;
}

// ==================== Chill ====================

EXPORT bool ADLX_Chill_IsEnabled(int gpuIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return false;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLX3DChillPtr chill;
    res = d3dSettingSrv->GetChill(gpu, &chill);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool enabled = false;
    chill->IsEnabled(&enabled);
    return enabled;
}

EXPORT int ADLX_Chill_SetEnabled(int gpuIndex, bool enabled)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return -1;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLX3DChillPtr chill;
    res = d3dSettingSrv->GetChill(gpu, &chill);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = chill->SetEnabled(enabled);
    return (int)res;
}

EXPORT int ADLX_Chill_GetMinFPS(int gpuIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return -1;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return -1;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return -1;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return -1;
    
    IADLX3DChillPtr chill;
    res = d3dSettingSrv->GetChill(gpu, &chill);
    if (!ADLX_SUCCEEDED(res)) return -1;
    
    adlx_int minFPS = 0;
    chill->GetMinFPS(&minFPS);
    return minFPS;
}

EXPORT int ADLX_Chill_GetMaxFPS(int gpuIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return -1;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return -1;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return -1;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return -1;
    
    IADLX3DChillPtr chill;
    res = d3dSettingSrv->GetChill(gpu, &chill);
    if (!ADLX_SUCCEEDED(res)) return -1;
    
    adlx_int maxFPS = 0;
    chill->GetMaxFPS(&maxFPS);
    return maxFPS;
}

EXPORT int ADLX_Chill_SetMinFPS(int gpuIndex, int minFPS)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return -1;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLX3DChillPtr chill;
    res = d3dSettingSrv->GetChill(gpu, &chill);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = chill->SetMinFPS(minFPS);
    return (int)res;
}

EXPORT int ADLX_Chill_SetMaxFPS(int gpuIndex, int maxFPS)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return -1;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLX3DChillPtr chill;
    res = d3dSettingSrv->GetChill(gpu, &chill);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = chill->SetMaxFPS(maxFPS);
    return (int)res;
}

// ==================== Boost ====================

EXPORT bool ADLX_Boost_IsEnabled(int gpuIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return false;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return false;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    IADLX3DBoostPtr boost;
    res = d3dSettingSrv->GetBoost(gpu, &boost);
    if (!ADLX_SUCCEEDED(res)) return false;
    
    adlx_bool enabled = false;
    boost->IsEnabled(&enabled);
    return enabled;
}

EXPORT int ADLX_Boost_SetEnabled(int gpuIndex, bool enabled)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return -1;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLX3DBoostPtr boost;
    res = d3dSettingSrv->GetBoost(gpu, &boost);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = boost->SetEnabled(enabled);
    return (int)res;
}

EXPORT int ADLX_Boost_GetResolution(int gpuIndex)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return -1;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return -1;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return -1;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return -1;
    
    IADLX3DBoostPtr boost;
    res = d3dSettingSrv->GetBoost(gpu, &boost);
    if (!ADLX_SUCCEEDED(res)) return -1;
    
    adlx_int resolution = 0;
    boost->GetResolution(&resolution);
    return resolution;
}

EXPORT int ADLX_Boost_SetResolution(int gpuIndex, int resolution)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!ensureInitialized()) return -1;
    
    IADLX3DSettingsServicesPtr d3dSettingSrv;
    ADLX_RESULT res = g_ADLXHelp.GetSystemServices()->Get3DSettingsServices(&d3dSettingSrv);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLXGPUListPtr gpus;
    res = g_ADLXHelp.GetSystemServices()->GetGPUs(&gpus);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    adlx_uint count = gpus->Size();
    if (gpuIndex >= (int)count) return -1;
    
    IADLXGPUPtr gpu;
    res = gpus->At(gpuIndex, &gpu);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    IADLX3DBoostPtr boost;
    res = d3dSettingSrv->GetBoost(gpu, &boost);
    if (!ADLX_SUCCEEDED(res)) return (int)res;
    
    res = boost->SetResolution(resolution);
    return (int)res;
}
