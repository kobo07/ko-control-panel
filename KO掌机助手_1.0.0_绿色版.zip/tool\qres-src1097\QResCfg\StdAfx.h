// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//
#if defined(__BORLANDC__)
#pragma warn -8022 // suppress warnings for MFC headers in BCPP 5.0
#pragma warn -8057 // suppress unused parameter warnings in BCPP 5.0
#pragma warn -8084 // suppress warning for MAKELONG in BCPP 5.0
#endif
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#define  WINVER  0x0400

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT




