// 完整设备检测模块 - 支持所有 MotionAssistant 中的设备
// 基于 MotionAssistant 1.2.0.7 反编译代码

const { execSync } = require('child_process');

// 所有支持的设备配置 - 完整版本
const ALL_DEVICE_CONFIG = {
  // ========== GPD 设备 ==========
  'GPD_Win5': {
    manufacturer: 'GPD',
    product: 'G1618-05',
    name: 'GPD Win 5',
    fanControl: {
      addresses: { control: 0x47A, control2: 0x47B },
      speedRead: { high: 0x478, low: 0x479 },
      maxSpeed: 244,
      portType: '4E4F'
    }
  },
  
  'GPD_Win4_7840U': {
    manufacturer: 'GPD',
    product: 'G1618-04',
    version: '1.0',
    name: 'GPD Win 4 (7840U)',
    fanControl: {
      addresses: { mode: 0x275, control: 0x1809 },
      speedRead: { high: 0x218, low: 0x219 },
      maxSpeed: 184,
      portType: '4E4F'
    }
  },
  
  'GPD_Win4_6800U': {
    manufacturer: 'GPD',
    product: 'G1618-04',
    version: 'other',
    name: 'GPD Win 4 (6800U)',
    fanControl: {
      addresses: { control: 0xC2F1 },
      speedRead: { high: 0xC880, low: 0xC881 },
      maxSpeed: 127,
      portType: '2E2F'
    }
  },
  
  'GPD_Win3': {
    manufacturer: 'GPD',
    product: 'G1618-03',
    name: 'GPD Win 3',
    fanControl: {
      addresses: { control: 0x44A, control2: 0x44B, control3: 0xC44A, control4: 0xC44B },
      speedRead: { value: 0x1809 },
      maxSpeed: 255,
      portType: '4E4F'
    }
  },
  
  'GPD_Winmax2_AMD': {
    manufacturer: 'GPD',
    product: 'G1619-04',
    name: 'GPD Win Max 2 (AMD)',
    fanControl: {
      addresses: { mode: 0x275, control: 0x1809 },
      speedRead: { high: 0x218, low: 0x219 },
      maxSpeed: 184,
      portType: '4E4F'
    }
  },
  
  'GPD_Winmax2_Intel': {
    manufacturer: 'GPD',
    product: 'G1619-03',
    name: 'GPD Win Max 2 (Intel)',
    fanControl: {
      addresses: { mode: 0x275, control: 0x1809 },
      speedRead: { high: 0x218, low: 0x219 },
      maxSpeed: 184,
      portType: '4E4F'
    }
  },
  
  'GPD_Winmax2_370': {
    manufacturer: 'GPD',
    product: 'G1619-05',
    name: 'GPD Win Max 2 (370)',
    fanControl: {
      addresses: { mode: 0x275, control: 0x1809 },
      speedRead: { high: 0x218, low: 0x219 },
      maxSpeed: 184,
      portType: '4E4F'
    }
  },
  
  'GPD_Winmax_1035G7': {
    manufacturer: 'GPD',
    product: 'G1619-01',
    name: 'GPD Win Max (1035G7)',
    fanControl: null
  },
  
  'GPD_Winmax_1195G7': {
    manufacturer: 'GPD',
    product: 'G1619-02',
    name: 'GPD Win Max (1195G7)',
    fanControl: null
  },
  
  'GPD_Win_Mini': {
    manufacturer: 'GPD',
    product: 'G1622-01',
    name: 'GPD Win Mini',
    fanControl: {
      addresses: { control: 0x47A },
      speedRead: { high: 0x478, low: 0x479 },
      maxSpeed: 244,
      portType: '4E4F'
    }
  },
  
  'GPD_Win_Mini_8840U': {
    manufacturer: 'GPD',
    product: 'G1622-01',
    special: 'NewMiniHengPing',
    name: 'GPD Win Mini (8840U)',
    fanControl: {
      addresses: { control: 0x47A },
      speedRead: { high: 0x478, low: 0x479 },
      maxSpeed: 244,
      portType: '4E4F'
    }
  },
  
  'GPD_Win_Mini_370': {
    manufacturer: 'GPD',
    product: 'G1617-02',
    name: 'GPD Win Mini (370)',
    fanControl: {
      addresses: { control: 0x47A },
      speedRead: { high: 0x478, low: 0x479 },
      maxSpeed: 244,
      portType: '4E4F'
    }
  },
  
  'GPD_Duo': {
    manufacturer: 'GPD',
    product: 'G1628-04',
    name: 'GPD Duo',
    fanControl: {
      addresses: { control: 0x47A, control2: 0x47B },
      speedRead: { high: 0x478, low: 0x479 },
      maxSpeed: 244,
      portType: '4E4F'
    }
  },
  
  'GPD_Pocket4': {
    manufacturer: 'GPD',
    product: 'G1624-01',
    name: 'GPD Pocket 4',
    fanControl: {
      addresses: { control: 0x47A },
      speedRead: { high: 0x478, low: 0x479 },
      maxSpeed: 244,
      portType: '4E4F'
    }
  },
  
  'GPD_MicroPC2': {
    manufacturer: 'GPD',
    product: 'G1688-08',
    name: 'GPD MicroPC 2',
    fanControl: {
      addresses: { control: 0x47A },
      speedRead: { high: 0x476, low: 0x477 },
      maxSpeed: 244,
      portType: '4E4F'
    }
  },
  
  // ========== AYANEO 设备 ==========
  'AYANEO_2021': {
    manufacturer: ['AYANEO', 'AYADEVICE'],
    product: 'default',
    name: 'AYANEO 2021',
    fanControl: null
  },
  
  'AYANEO_FOUNDER': {
    manufacturer: ['AYANEO', 'AYADEVICE'],
    product: ['AYA NEO FOUNDER', 'AYA NEO Fouder'],
    name: 'AYANEO Founder',
    fanControl: null
  },
  
  'AYANEO_Next': {
    manufacturer: ['AYANEO', 'AYADEVICE'],
    product: ['AYANEO NEXT Pro', 'AYANEO NEXT', 'NEXT Advance', 'NEXT Pro', 'NEXT', 'AYANEO NEXT Advance'],
    name: 'AYANEO Next',
    fanControl: null
  },
  
  'AYANEO2': {
    manufacturer: ['AYANEO', 'AYADEVICE'],
    product: ['AYANEO 2', 'GEEK'],
    name: 'AYANEO 2',
    fanControl: {
      addresses: { control: 0x44A, control2: 0x44B, control3: 0xC44A, control4: 0xC44B },
      speedRead: { value: 0x1809 },
      maxSpeed: 255,
      portType: '4E4F'
    }
  },
  
  'AYANEO_2S': {
    manufacturer: ['AYANEO', 'AYADEVICE'],
    product: ['GEEK 1S', 'AYANEO 2S'],
    name: 'AYANEO 2S',
    fanControl: {
      addresses: { control: 0x44A, control2: 0x44B, control3: 0xC44A, control4: 0xC44B },
      speedRead: { value: 0x1809 },
      maxSpeed: 255,
      portType: '4E4F'
    }
  },
  
  'AYANEO_Air': {
    manufacturer: ['AYANEO', 'AYADEVICE'],
    product: ['AIR Pro', 'AIR'],
    name: 'AYANEO Air',
    fanControl: {
      addresses: { control: 0x44A, control2: 0x44B, control3: 0xC44A, control4: 0xC44B },
      speedRead: { value: 0x1803 },
      maxSpeed: 255,
      portType: '4E4F'
    }
  },
  
  'AYANEO_Air_1S': {
    manufacturer: ['AYANEO', 'AYADEVICE'],
    product: 'AIR 1S',
    name: 'AYANEO Air 1S',
    fanControl: {
      addresses: { control: 0x44A, control2: 0x44B, control3: 0xC44A, control4: 0xC44B },
      speedRead: { value: 0x1809 },
      maxSpeed: 255,
      portType: '4E4F'
    }
  },
  
  'AYANEO_Air_Plus_6800U': {
    manufacturer: ['AYANEO', 'AYADEVICE'],
    product: 'AB05-AMD',
    name: 'AYANEO Air Plus (6800U)',
    fanControl: {
      addresses: { control: 0xD1C8 },
      speedRead: { value: 0x1804 },
      maxSpeed: 255,
      portType: '4E4F'
    }
  },
  
  'AYANEO_KUN': {
    manufacturer: ['AYANEO', 'AYADEVICE'],
    product: 'KUN',
    name: 'AYANEO KUN',
    fanControl: {
      addresses: { control: 0x44A, control2: 0x44B, control3: 0xC44A, control4: 0xC44B },
      speedRead: { value: 0x1809 },
      maxSpeed: 255,
      portType: '4E4F'
    }
  },
  
  // ========== OneXPlayer 设备 ==========
  'OnexPlayer_AMD': {
    manufacturer: ['ONE-NETBOOK TECHNOLOGY CO., LTD.', 'ONE-NETBOOK'],
    product: 'ONE XPLAYER',
    version: ['V01', '!1002-C'],
    name: 'OneXPlayer (AMD)',
    fanControl: {
      addresses: { control: 0x44A, control2: 0x44B },
      speedRead: { value: 0x1809 },
      maxSpeed: 255,
      portType: '4E4F'
    }
  },
  
  'OnexPlayer_Intel': {
    manufacturer: ['ONE-NETBOOK TECHNOLOGY CO., LTD.', 'ONE-NETBOOK'],
    product: 'ONE XPLAYER',
    version: '1002-C',
    name: 'OneXPlayer (Intel)',
    fanControl: null
  },
  
  'OnexPlayer_MiniPro': {
    manufacturer: ['ONE-NETBOOK TECHNOLOGY CO., LTD.', 'ONE-NETBOOK'],
    product: 'ONEXPLAYER Mini Pro',
    name: 'OneXPlayer Mini Pro',
    fanControl: {
      addresses: { control: 0x44A, control2: 0x44B },
      speedRead: { value: 0x1809 },
      maxSpeed: 255,
      portType: '4E4F'
    }
  },
  
  'OnexPlayer_2': {
    manufacturer: ['ONE-NETBOOK TECHNOLOGY CO., LTD.', 'ONE-NETBOOK'],
    product: ['ONEXPLAYER 2 ARP23', 'ONEXPLAYER 2 PRO ARP23P EVA-01'],
    name: 'OneXPlayer 2',
    fanControl: {
      addresses: { control: 0x44A, control2: 0x44B },
      speedRead: { value: 0x1809 },
      maxSpeed: 184,
      portType: '4E4F'
    }
  },
  
  'OnexPlayer_F1': {
    manufacturer: ['ONE-NETBOOK TECHNOLOGY CO., LTD.', 'ONE-NETBOOK'],
    product: 'ONEXPLAYER F1',
    name: 'OneXPlayer F1',
    fanControl: {
      addresses: { control: 0x44A, control2: 0x44B },
      speedRead: { value: 0x1809 },
      maxSpeed: 255,
      portType: '4E4F'
    }
  },
  
  // ========== AOKZOE 设备 ==========
  'AOKZOE_A1': {
    manufacturer: 'AOKZOE',
    product: ['AOKZOE A1 Pro', 'AOKZOE A1 AR07'],
    name: 'AOKZOE A1',
    fanControl: {
      addresses: { control: 0x44A, control2: 0x44B },
      speedRead: { value: 0x1809 },
      maxSpeed: 255,
      portType: '4E4F'
    }
  },
  
  // ========== ROG Ally 设备 ==========
  'ROG_ALLY_Z1E': {
    manufacturer: 'ASUSTEK COMPUTER INC.',
    product: 'RC71L',
    name: 'ROG Ally (Z1 Extreme)',
    fanControl: {
      type: 'ACPI',
      maxSpeed: 100,
      note: '使用 ASUS ACPI 接口控制'
    }
  },
  
  'ROG_ALLY_X_Z1E': {
    manufacturer: 'ASUSTEK COMPUTER INC.',
    product: 'RC72LA',
    name: 'ROG Ally X (Z1 Extreme)',
    fanControl: {
      type: 'ACPI',
      maxSpeed: 100,
      note: '使用 ASUS ACPI 接口控制'
    }
  },
  
  'ROG_ALLY_X_Z2E': {
    manufacturer: 'ASUSTEK COMPUTER INC.',
    product: 'RC73XA',
    name: 'ROG Ally X (Z2 Extreme)',
    fanControl: {
      type: 'ACPI',
      maxSpeed: 100,
      note: '使用 ASUS ACPI 接口控制'
    }
  },
  
  // ========== AYN 设备 ==========
  'AYN_Loki_Max': {
    manufacturer: 'AYN',
    product: 'Loki Max',
    name: 'AYN Loki Max',
    fanControl: {
      addresses: { mode: 0x310, control: 0x311 },
      speedRead: { value: 0x311 },
      maxSpeed: 128,
      portType: '2E2F'
    }
  },
  
  // ========== Lenovo 设备 ==========
  'Legion_Go_8APU1': {
    manufacturer: 'LENOVO',
    sku: 'Legion Go 8APU1',
    name: 'Lenovo Legion Go (8APU1)',
    fanControl: {
      type: 'WMI',
      maxSpeed: 245,
      note: '使用 Lenovo WMI 接口控制'
    }
  },
  
  'Legion_Go_S_8ARP1': {
    manufacturer: 'LENOVO',
    sku: 'Legion Go S 8ARP1',
    name: 'Lenovo Legion Go S (8ARP1)',
    fanControl: {
      addresses: { control: 0x1804 },
      speedRead: { value: 0x1804 },
      maxSpeed: 127,
      portType: '4E4F'
    }
  },
  
  // ========== 其他品牌设备 ==========
  'LingLong': {
    manufacturer: 'SU',
    product: 'ARB33P',
    name: 'LingLong',
    fanControl: {
      addresses: { mode: 0xF02, control: 0x1809 },
      speedRead: { high: 0x218, low: 0x219 },
      maxSpeed: 184,
      portType: '4E4F'
    }
  },
  
  'Zotac_G0A1W': {
    manufacturer: 'PC PARTNER LIMITED',
    product: 'G0A1W',
    name: 'Zotac Zone',
    fanControl: {
      type: 'ECIO',
      addresses: { mode: 0x4A, control: 0x4B },
      speedRead: { value: 0x4B },
      maxSpeed: 255,
      note: '使用 EC I/O 端口控制'
    }
  },
  
  'OrangePi_Neo01': {
    manufacturer: 'ORANGEPI',
    product: 'NEO-01',
    name: 'Orange Pi Neo',
    fanControl: {
      type: 'ECIO',
      addresses: { mode: 0x40, control: 0x38 },
      speedRead: { high: 0x78, low: 0x79 },
      maxSpeed: 244,
      note: '使用 EC I/O 端口控制'
    }
  },
  
  // ========== MSI 设备 ==========
  'MSI_Claw_A1M': {
    manufacturer: 'MICRO-STAR INTERNATIONAL CO., LTD.',
    systemProduct: 'Claw A1M',
    name: 'MSI Claw A1M',
    fanControl: {
      type: 'MSI',
      maxSpeed: 100,
      note: '使用 MSI EC 接口控制'
    }
  },
  
  'MSI_Claw7_A2VM': {
    manufacturer: 'MICRO-STAR INTERNATIONAL CO., LTD.',
    systemProduct: 'Claw 7 AI+ A2VM',
    name: 'MSI Claw 7 AI+',
    fanControl: {
      type: 'MSI',
      maxSpeed: 100,
      note: '使用 MSI EC 接口控制'
    }
  },
  
  'MSI_Claw8_A2VM': {
    manufacturer: 'MICRO-STAR INTERNATIONAL CO., LTD.',
    systemProduct: 'Claw 8 AI+ A2VM',
    name: 'MSI Claw 8 AI+',
    fanControl: {
      type: 'MSI',
      maxSpeed: 100,
      note: '使用 MSI EC 接口控制'
    }
  },
  
  'MSI_ClawA8_BZ2EM': {
    manufacturer: 'MICRO-STAR INTERNATIONAL CO., LTD.',
    systemProduct: 'Claw A8 BZ2EM',
    name: 'MSI Claw A8',
    fanControl: null
  },
  
  // ========== Microsoft 设备 ==========
  'Surface_Pro_8': {
    manufacturer: 'MICROSOFT CORPORATION',
    product: ['Surface Pro 8', 'Surface Pro 6'],
    name: 'Microsoft Surface Pro',
    fanControl: null
  }
};

/**
 * 获取系统信息 (使用 PowerShell，兼容新版 Windows 11)
 */
function getSystemInfo() {
  try {
    // 使用 PowerShell Get-CimInstance 替代已废弃的 wmic
    const baseboardCmd = `powershell -NoProfile -Command "Get-CimInstance -ClassName Win32_BaseBoard | Select-Object -Property Manufacturer,Product,Version | ConvertTo-Json"`;
    const baseboardJson = execSync(baseboardCmd, { encoding: 'utf8' });
    const baseboard = JSON.parse(baseboardJson.trim());
    
    const manufacturer = (baseboard.Manufacturer || '').trim().toUpperCase();
    const product = (baseboard.Product || '').trim();
    const version = (baseboard.Version || '').trim();
    
    // 获取 SKU/Model 信息 (用于 Lenovo 设备)
    let sku = '';
    try {
      const skuCmd = `powershell -NoProfile -Command "(Get-CimInstance -ClassName Win32_ComputerSystem).Model"`;
      sku = execSync(skuCmd, { encoding: 'utf8' }).trim();
    } catch (e) {
      // SKU 获取失败，继续
    }
    
    // 获取系统产品名称 (用于 MSI 设备)
    let systemProduct = '';
    try {
      const sysCmd = `powershell -NoProfile -Command "(Get-CimInstance -ClassName Win32_ComputerSystem).Name"`;
      systemProduct = execSync(sysCmd, { encoding: 'utf8' }).trim();
    } catch (e) {
      // 系统产品名称获取失败，继续
    }
    
    return { manufacturer, product, version, sku, systemProduct };
  } catch (error) {
    console.error('Failed to get system info:', error.message);
    // 回退到 wmic（兼容旧版 Windows）
    return getSystemInfoWmic();
  }
}

/**
 * 使用 wmic 获取系统信息（旧版 Windows 兼容）
 */
function getSystemInfoWmic() {
  try {
    const wmi = execSync(
      'wmic baseboard get manufacturer,product,version /format:list',
      { encoding: 'utf8' }
    );
    
    const manufacturer = wmi.match(/Manufacturer=(.*)/)?.[1]?.trim().toUpperCase();
    const product = wmi.match(/Product=(.*)/)?.[1]?.trim();
    const version = wmi.match(/Version=(.*)/)?.[1]?.trim();
    
    let sku = '';
    try {
      const skuWmi = execSync('wmic computersystem get model /format:list', { encoding: 'utf8' });
      sku = skuWmi.match(/Model=(.*)/)?.[1]?.trim() || '';
    } catch (e) {}
    
    let systemProduct = '';
    try {
      const sysWmi = execSync('wmic computersystem get name /format:list', { encoding: 'utf8' });
      systemProduct = sysWmi.match(/Name=(.*)/)?.[1]?.trim() || '';
    } catch (e) {}
    
    return { manufacturer, product, version, sku, systemProduct };
  } catch (error) {
    console.error('Failed to get system info (wmic fallback):', error.message);
    return null;
  }
}

/**
 * 检测是否为 Win Mini 8840U 版本
 */
function isWinMini8840U() {
  try {
    // 使用 PowerShell 替代 wmic
    const monitorCmd = `powershell -NoProfile -Command "(Get-CimInstance -ClassName Win32_DesktopMonitor).PNPDeviceID"`;
    const monitor = execSync(monitorCmd, { encoding: 'utf8' });
    return monitor.includes('NewMiniHengPing');
  } catch (error) {
    // 回退到 wmic
    try {
      const monitor = execSync(
        'wmic desktopmonitor get PNPDeviceID /format:list',
        { encoding: 'utf8' }
      );
      return monitor.includes('NewMiniHengPing');
    } catch (e) {
      return false;
    }
  }
}

/**
 * 匹配设备配置
 */
function matchDevice(info) {
  const { manufacturer, product, version, sku, systemProduct } = info;
  
  for (const [deviceType, config] of Object.entries(ALL_DEVICE_CONFIG)) {
    // 匹配制造商
    const mfgMatch = Array.isArray(config.manufacturer)
      ? config.manufacturer.some(m => manufacturer?.includes(m.toUpperCase()))
      : manufacturer?.includes(config.manufacturer?.toUpperCase());
    
    if (!mfgMatch) continue;
    
    // 匹配产品型号 (使用包含匹配而非严格相等，提高兼容性)
    if (config.product) {
      const products = Array.isArray(config.product) ? config.product : [config.product];
      const productMatch = products.some(p => {
        if (p === 'default') return true;
        if (p.startsWith('!')) return !product?.includes(p.substring(1));
        // 使用包含匹配：产品名包含配置中的字符串即可
        return product?.includes(p);
      });
      
      if (!productMatch) continue;
    }
    
    // 匹配版本
    if (config.version) {
      const versions = Array.isArray(config.version) ? config.version : [config.version];
      const versionMatch = versions.some(v => {
        if (v === 'other') return !version?.includes('1.0');
        if (v.startsWith('!')) return version !== v.substring(1);
        return version?.includes(v);
      });
      
      if (!versionMatch) continue;
    }
    
    // 匹配 SKU (Lenovo)
    if (config.sku && !sku?.includes(config.sku)) continue;
    
    // 匹配系统产品名称 (MSI)
    if (config.systemProduct && systemProduct !== config.systemProduct) continue;
    
    // 特殊检测 (Win Mini 8840U)
    if (config.special === 'NewMiniHengPing' && !isWinMini8840U()) continue;
    
    return { type: deviceType, ...config };
  }
  
  return null;
}

/**
 * 自动检测设备
 */
function autoDetectDevice() {
  const info = getSystemInfo();
  if (!info) {
    console.warn('⚠️  Failed to get system information');
    return null;
  }
  
  console.log('=== Device Detection ===');
  console.log('System Info:', JSON.stringify(info, null, 2));
  console.log('  Manufacturer:', info.manufacturer);
  console.log('  Product:', info.product);
  console.log('  Version:', info.version);
  
  const device = matchDevice(info);
  
  if (device) {
    console.log(`✓ Detected: ${device.name} (${device.type})`);
    
    if (device.fanControl) {
      if (device.fanControl.type === 'ACPI') {
        console.log(`  Fan control: ASUS ACPI (via WMI)`);
        return device;
      } else if (device.fanControl.type === 'WMI') {
        console.log(`  Fan control: Lenovo WMI`);
        return device;
      } else if (device.fanControl.type === 'ECIO') {
        console.log(`  Fan control: EC I/O Port`);
        return device;
      } else if (device.fanControl.type === 'MSI') {
        console.log(`  Fan control: MSI EC (not yet implemented)`);
        return { ...device, fanControlDisabled: true };
      } else {
        console.log(`  Fan control: EC RAM (${device.fanControl.portType})`);
        return device;
      }
    } else {
      console.log(`  Fan control: Not supported by hardware`);
      return { ...device, fanControlDisabled: true };
    }
  }
  
  console.warn('⚠️  Unknown device - Fan control disabled for safety');
  return null;
}

module.exports = {
  getSystemInfo,
  autoDetectDevice,
  ALL_DEVICE_CONFIG
};
