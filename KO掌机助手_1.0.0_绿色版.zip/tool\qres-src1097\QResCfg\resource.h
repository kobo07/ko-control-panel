//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by QResCfg.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_QRESCFG_DIALOG              102
#define IDS_PROPSHT_CAPTION             103
#define IDD_PROPPAGE1                   104
#define IDS_STARTMENU                   104
#define IDD_PROPPAGE2                   105
#define IDS_DESKTOP                     105
#define IDD_PROPPAGE3                   106
#define IDS_NEWLINK                     106
#define IDD_PROPPAGE4                   107
#define IDS_REM_STARTMENU               107
#define IDS_REM_DESKTOP                 108
#define IDS_PROMPT2                     109
#define IDS_PROMPT2_REM                 110
#define IDS_FINISH1                     111
#define IDS_FINISH2                     112
#define IDS_TEST1                       113
#define IDS_TEST2                       114
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     138
#define IDB_BITMAP2                     139
#define IDB_BITMAP3                     143
#define IDD_ADVANCED                    146
#define HID_PROPPAGE1                   201
#define HID_PROPPAGE2                   202
#define HID_PROPPAGE3                   203
#define HID_PROPPAGE4                   204
#define IDC_EDIT1                       1001
#define IDC_COLOR                       1010
#define IDC_AREA                        1011
#define IDC_AREA_TXT                    1012
#define IDC_RESTORE                     1013
#define IDC_TASKBAR                     1015
#define IDC_STARTMENU                   1015
#define IDC_DESKTOP                     1016
#define IDC_NEWLINK                     1017
#define IDC_DIRTREE                     1022
#define IDC_FILELIST                    1023
#define IDC_TEST                        1024
#define IDC_SUMMARY                     1025
#define IDC_LIST1                       1026
#define IDC_LIST2                       1027
#define IDC_NOCOLOR                     1027
#define IDC_NOAREA                      1028
#define IDC_LESS                        1029
#define IDC_MORE                        1030
#define IDC_ADDQRES                     1033
#define IDC_PROMPT                      1034
#define IDC_REMQRES                     1035
#define IDC_TEST_TXT                    1035
#define IDC_FINISH_TXT                  1036
#define IDC_REFRESH                     1038
#define IDC_DIRECT                      1039
#define IDC_WAIT_SPIN                   1040
#define IDC_ADVANCED                    1041
#define IDC_REFRESH_TXT                 1042
#define IDC_WAIT_TXT                    1043
#define IDC_WAIT_EDT                    1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
